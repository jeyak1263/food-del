import React from 'react'
import './cart.css'

const cart = () => {
  return (
    <div>
      
    </div>
  )
}

export default cart
